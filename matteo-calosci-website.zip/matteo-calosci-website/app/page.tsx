import Link from "next/link"
import { ArrowRight, Calendar, Mail, Music } from "lucide-react"
import Script from "next/script"

import { Button } from "@/components/ui/button"
import HeroSection from "@/components/hero-section"
import MusicPlayer from "@/components/music-player"
import PerformanceCard from "@/components/performance-card"
import GallerySection from "@/components/gallery-section"
import ScrollReveal from "@/components/scroll-reveal"
import ViolinModel from "@/components/violin-model"

export default function Home() {
  // Dati strutturati per Schema.org
  const schemaData = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: "Matteo Calosci",
    url: "https://www.matteocalosci.com",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WEBSITE%20BG1%20copia.jpg-C6gU84gsQ8WSBLOyjg4Helr6YAohkK.jpeg",
    sameAs: [
      "https://www.facebook.com/matteo.calosci.9/?locale=it_IT",
      "https://www.instagram.com/matteo__calosci/",
      "https://www.youtube.com/matteocalosci",
    ],
    jobTitle: "Violinista",
    description:
      "Matteo Calosci, violinista e docente presso il Conservatorio di Reggio Calabria, si esibisce in concerti in Italia e all'estero.",
    performerIn: [
      {
        "@type": "MusicEvent",
        name: "Recital al Teatro dell'Opera",
        startDate: "2024-06-15T20:00",
        location: {
          "@type": "Place",
          name: "Teatro dell'Opera",
          address: {
            "@type": "PostalAddress",
            addressLocality: "Roma",
            addressCountry: "IT",
          },
        },
        offers: {
          "@type": "Offer",
          url: "https://www.matteocalosci.com/tickets/roma-2024",
          price: "35",
          priceCurrency: "EUR",
          availability: "https://schema.org/InStock",
        },
      },
      {
        "@type": "MusicEvent",
        name: "Festival di Musica da Camera",
        startDate: "2024-07-08T19:30",
        location: {
          "@type": "Place",
          name: "Musikverein",
          address: {
            "@type": "PostalAddress",
            addressLocality: "Vienna",
            addressCountry: "AT",
          },
        },
      },
    ],
  }

  return (
    <div className="flex min-h-screen flex-col">
      {/* Schema.org JSON-LD */}
      <Script
        id="schema-org-data"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
      />

      <HeroSection />

      {/* Biography Section */}
      <section id="biography" className="py-20 px-4 md:px-6 lg:px-8 bg-white">
        <div className="container mx-auto max-w-5xl">
          <ScrollReveal>
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">Biografia</h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <ScrollReveal direction="right" delay={0.2}>
              <div className="relative h-[400px] overflow-hidden rounded-lg shadow-xl">
                <div className="absolute inset-0 bg-gradient-to-br from-black/20 to-black/60 z-10"></div>
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WEBSITE%20BG1%20copia.jpg-C6gU84gsQ8WSBLOyjg4Helr6YAohkK.jpeg"
                  alt="Matteo Calosci violinista durante un'esibizione"
                  className="w-full h-full object-cover object-center"
                />
              </div>
            </ScrollReveal>

            <div className="space-y-3 flex flex-col justify-between h-[400px]">
              <div className="space-y-3 overflow-auto">
                <ScrollReveal direction="left" delay={0.3}>
                  <p className="text-base text-black text-justify">
                    Matteo Calosci, erede della prestigiosa scuola del Mº Zakhar Bron, è docente di violino presso il
                    Conservatorio di Reggio Calabria e presso i corsi di perfezionamento città di Padova.
                  </p>
                </ScrollReveal>

                <ScrollReveal direction="left" delay={0.4}>
                  <p className="text-base text-black text-justify">
                    Si esibisce regolarmente come solista e in formazioni da camera. Vanta concerti in prestigiose sale
                    e per rinomate istituzioni musicali tra cui Sala Verdi Milano, Serate Musicali, Auditorio Nacional
                    Madrid, Palazzo del Quirinale Roma, Teatro San Babila Milano, Museo del 900 Milano, Teatro
                    Sperimentale Ancona, Teatro Elfo Puccini Milano, Auditorium Palazzina Liberty Milano, Teatro Goldoni
                    Firenze.
                  </p>
                </ScrollReveal>
              </div>

              <ScrollReveal direction="left" delay={0.5}>
                <Button variant="outline" className="mt-4 group border-black text-black hover:bg-black/5">
                  Leggi la biografia completa
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Button>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <GallerySection />

      {/* Performances Section */}
      <section id="performances" className="py-20 px-4 md:px-6 lg:px-8 bg-gray-50">
        <div className="container mx-auto max-w-5xl">
          <ScrollReveal>
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">Prossimi Eventi</h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ScrollReveal direction="up" delay={0.2}>
              <PerformanceCard
                title="Recital al Teatro dell'Opera"
                date="15 Giugno, 2024"
                location="Roma, Italia"
                image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WEBSITE%20BG.tiff-5WyRsAlX0AiMAQGA9c4V92cQZviGpF.jpeg"
              />
            </ScrollReveal>

            <ScrollReveal direction="up" delay={0.3}>
              <PerformanceCard
                title="Festival di Musica da Camera"
                date="8 Luglio, 2024"
                location="Vienna, Austria"
                image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WEBSITE%20BG1%20copia.jpg-C6gU84gsQ8WSBLOyjg4Helr6YAohkK.jpeg"
              />
            </ScrollReveal>

            <ScrollReveal direction="up" delay={0.4}>
              <PerformanceCard
                title="Solista con Orchestra Sinfonica"
                date="22 Agosto, 2024"
                location="Berlino, Germania"
                image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WEBSITE%20BG.tiff-5WyRsAlX0AiMAQGA9c4V92cQZviGpF.jpeg"
              />
            </ScrollReveal>

            <ScrollReveal direction="up" delay={0.5}>
              <PerformanceCard
                title="Concorso Internazionale di Violino"
                date="10 Settembre, 2024"
                location="Parigi, Francia"
                image="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WEBSITE%20BG1%20copia.jpg-C6gU84gsQ8WSBLOyjg4Helr6YAohkK.jpeg"
              />
            </ScrollReveal>
          </div>

          <ScrollReveal delay={0.6}>
            <div className="mt-10 text-center">
              <Button variant="outline" className="group" asChild>
                <Link href="/eventi" target="_blank">
                  Vedi tutti i prossimi eventi
                  <Calendar className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* 3D Model Section */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-white">
        <div className="container mx-auto max-w-5xl">
          <ScrollReveal>
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">Il Violino</h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <ScrollReveal direction="right" delay={0.2}>
              <ViolinModel />
            </ScrollReveal>

            <div className="space-y-4">
              <ScrollReveal direction="left" delay={0.3}>
                <h3 className="text-2xl font-semibold">La Passione per lo Strumento</h3>
              </ScrollReveal>

              <ScrollReveal direction="left" delay={0.4}>
                <p className="text-lg text-gray-700 text-justify">
                  Matteo Calosci suona un violino italiano del XVIII secolo, uno strumento che lo accompagna in ogni sua
                  esibizione e che rappresenta la sua voce artistica.
                </p>
              </ScrollReveal>

              <ScrollReveal direction="left" delay={0.5}>
                <p className="text-lg text-gray-700 text-justify">
                  La ricerca del suono perfetto e l'attenzione ai dettagli tecnici sono elementi fondamentali del suo
                  approccio musicale, sempre volto a valorizzare le caratteristiche uniche del suo strumento.
                </p>
              </ScrollReveal>

              <ScrollReveal direction="left" delay={0.6}>
                <div className="mt-4 flex gap-2">
                  <span className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                    Tecnica
                  </span>
                  <span className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                    Espressività
                  </span>
                  <span className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                    Virtuosismo
                  </span>
                </div>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>

      {/* Music Section */}
      <section id="music" className="py-20 px-4 md:px-6 lg:px-8 bg-gray-50">
        <div className="container mx-auto max-w-5xl">
          <ScrollReveal>
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">Musica</h2>
          </ScrollReveal>

          <div className="space-y-8">
            <ScrollReveal delay={0.2}>
              <MusicPlayer title="Bach: Partita No. 2 in D minor, BWV 1004 - Chaconne" duration="13:42" />
            </ScrollReveal>

            <ScrollReveal delay={0.3}>
              <MusicPlayer title="Vivaldi: Le Quattro Stagioni - Primavera" duration="9:57" />
            </ScrollReveal>

            <ScrollReveal delay={0.4}>
              <MusicPlayer title="Paganini: Capriccio No. 24 in La minore" duration="4:26" />
            </ScrollReveal>
          </div>

          <ScrollReveal delay={0.5}>
            <div className="mt-10 text-center">
              <Button className="group">
                Esplora la discografia completa
                <Music className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-20 px-4 md:px-6 lg:px-8 bg-black text-white">
        <div className="container mx-auto max-w-5xl">
          <ScrollReveal>
            <h2 className="text-3xl md:text-4xl font-bold mb-6 md:mb-8 text-center">Contatti</h2>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10">
            <div className="space-y-5 md:space-y-6">
              <ScrollReveal direction="right" delay={0.2}>
                <h3 className="text-xl md:text-2xl font-semibold">Rimaniamo in Contatto</h3>
              </ScrollReveal>

              <ScrollReveal direction="right" delay={0.3}>
                <p className="text-white text-sm md:text-base text-justify">
                  Per prenotazioni, collaborazioni o qualsiasi altra informazione, non esitare a contattare il team di
                  management di Matteo.
                </p>
              </ScrollReveal>

              <ScrollReveal direction="right" delay={0.4}>
                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 md:h-5 md:w-5 text-primary flex-shrink-0" />
                  <span className="text-sm md:text-base break-all">contact@matteocalosci.com</span>
                </div>
              </ScrollReveal>

              <ScrollReveal direction="right" delay={0.6}>
                <div className="flex space-x-4 mt-4 md:mt-6">
                  <Link
                    href="https://www.facebook.com/matteo.calosci.9/?locale=it_IT"
                    className="h-8 w-8 md:h-10 md:w-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary hover:text-black transition-colors"
                    aria-label="Facebook di Matteo Calosci"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <span className="sr-only">Facebook</span>
                    <svg className="h-4 w-4 md:h-5 md:w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fillRule="evenodd"
                        d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </Link>
                  <Link
                    href="https://www.instagram.com/matteo__calosci/"
                    className="h-8 w-8 md:h-10 md:w-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary hover:text-black transition-colors"
                    aria-label="Instagram di Matteo Calosci"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <span className="sr-only">Instagram</span>
                    <svg className="h-4 w-4 md:h-5 md:w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fillRule="evenodd"
                        d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </Link>
                  <Link
                    href="https://www.youtube.com/matteocalosci"
                    className="h-8 w-8 md:h-10 md:w-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary hover:text-black transition-colors"
                    aria-label="YouTube di Matteo Calosci"
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    <span className="sr-only">YouTube</span>
                    <svg className="h-4 w-4 md:h-5 md:w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fillRule="evenodd"
                        d="M19.812 5.418c.861.23 1.538.907 1.768 1.768C21.998 8.746 22 12 22 12s0 3.255-.418 4.814a2.504 2.504 0 0 1-1.768 1.768c-1.56.419-7.814.419-7.814.419s-6.255 0-7.814-.419a2.505 2.505 0 0 1-1.768-1.768C2 15.255 2 12 2 12s0-3.255.417-4.814a2.507 2.507 0 0 1 1.768-1.768C5.744 5 11.998 5 11.998 5s6.255 0 7.814.418ZM15.194 12 10 15V9l5.194 3Z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </Link>
                </div>
              </ScrollReveal>
            </div>

            <ScrollReveal direction="left" delay={0.3}>
              <form className="space-y-3 md:space-y-4">
                <div className="grid grid-cols-1 gap-3 md:gap-4 sm:grid-cols-2">
                  <div className="space-y-1 md:space-y-2">
                    <label htmlFor="name" className="text-xs md:text-sm font-medium">
                      Nome
                    </label>
                    <input
                      id="name"
                      type="text"
                      className="w-full px-3 py-2 border border-gray-700 rounded-md bg-gray-800 text-white text-sm md:text-base"
                      placeholder="Il tuo nome"
                    />
                  </div>
                  <div className="space-y-1 md:space-y-2">
                    <label htmlFor="email" className="text-xs md:text-sm font-medium">
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      className="w-full px-3 py-2 border border-gray-700 rounded-md bg-gray-800 text-white text-sm md:text-base"
                      placeholder="La tua email"
                    />
                  </div>
                </div>
                <div className="space-y-1 md:space-y-2">
                  <label htmlFor="subject" className="text-xs md:text-sm font-medium">
                    Oggetto
                  </label>
                  <input
                    id="subject"
                    type="text"
                    className="w-full px-3 py-2 border border-gray-700 rounded-md bg-gray-800 text-white text-sm md:text-base"
                    placeholder="Oggetto"
                  />
                </div>
                <div className="space-y-1 md:space-y-2">
                  <label htmlFor="message" className="text-xs md:text-sm font-medium">
                    Messaggio
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    className="w-full px-3 py-2 border border-gray-700 rounded-md bg-gray-800 text-white text-sm md:text-base"
                    placeholder="Il tuo messaggio"
                  ></textarea>
                </div>
                <Button className="w-full">Invia Messaggio</Button>
              </form>
            </ScrollReveal>
          </div>
        </div>
      </section>

      <footer className="py-4 md:py-6 px-4 md:px-6 lg:px-8 bg-black text-white text-center">
        <div className="container mx-auto">
          <p className="text-sm md:text-base">
            © {new Date().getFullYear()} Matteo Calosci. Tutti i diritti riservati.
          </p>
          <div className="mt-2 text-xs md:text-sm text-gray-400">
            <Link href="/privacy-policy" className="hover:text-primary">
              Privacy Policy
            </Link>{" "}
            |
            <Link href="/termini-e-condizioni" className="ml-2 hover:text-primary">
              Termini e Condizioni
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

